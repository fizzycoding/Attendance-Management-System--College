import mysql.connector as mysql


def getDB():
    db_name = "college_database"
    try:

        connection = mysql.connect(host="localhost", user="root", password="")

        cursor = connection.cursor()
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
        cursor.execute(f"USE {db_name}")

        return connection

    except Exception as e:
        raise Exception(e)
