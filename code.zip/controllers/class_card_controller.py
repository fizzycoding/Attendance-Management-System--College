from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFrame

from ui.components.class_card_ui import Ui_class_card


class ClassCardController(QFrame, Ui_class_card):
    clicked = Signal(str)

    def __init__(self, classId, className, total, present, absent):
        super().__init__()
        self.setupUi(self)
        self.classId = classId
        self.class_name.setText(className)
        self.total_user_label.setText(str(total))
        self.present_label.setText(str(present))
        self.absent_label.setText(str(absent))

        self.btn_delete.clicked.connect(self.deleteClass)

    def deleteClass(self):
        print("CLass to delete: ", self.classId)
        pass

    def mousePressEvent(self, event):
        self.clicked.emit(self.classId)
        super().mousePressEvent(event)
