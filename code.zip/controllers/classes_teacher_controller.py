from PySide6.QtWidgets import QWidget

from controllers.class_card_controller import ClassCardController
from controllers.create_class_popup_controller import CreateClassPopup
from ui.classes_teacher_ui import Ui_classes_teacher


class ClassesTeacherController(QWidget):
    def __init__(self, user):
        super().__init__()
        self.ui = Ui_classes_teacher()
        self.ui.setupUi(self)
        self.user = user
        self.ui.btn_new_class.clicked.connect(self.showCreateClassPopup)

    def showCreateClassPopup(self):
        popUp = CreateClassPopup(parent=self)

        if popUp.exec():
            name = popUp.getClassName()
            print(name)

    def createNewClass(self):
        for c in range(4):
            card = ClassCardController(str(c + 1), f"BCom {c + 1}st", 23, 10, 11)
            card.clicked.connect(lambda id: print(id))
            # self.ui.classesLayout.addWidget(card)
            self.ui.classesLayout.insertWidget(0, card)
